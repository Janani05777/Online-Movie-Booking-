<head>
<style>
  .content-top {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 30px;
    padding: 20px;
}

.movie-item {
    width: 220px;
    text-align: center;
}

.movie-image {
    width: 220px;
    height: 320px;
    object-fit: cover;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0,0,0,0.3);
}


.movie-text {
    margin-top: 10px;
    font-size: 14px;
    color: #000;
}

.h-text {
    font-size: 16px;
    margin: 10px 0 5px 0;
}

.section-header {
    text-align: center;
    margin-top: 30px;
    margin-bottom: 40px;
}

.section-header h1 {
    color: black;
    font-size: 36px;
    font-weight: bold;
}

@media (max-width: 768px) {
    .movie-item {
        width: 45%;
    }
}

@media (max-width: 480px) {
    .movie-item {
        width: 100%;
    }
}

</style>
</head>

<?php include('header.php'); ?>
<link rel="stylesheet" type="text/css" href="styles.css">
</div>
<div class="content">
    <div class="wrap">
        <div class="section-header">
            <h1>NOW SHOWING</h1>
        </div>
        <div class="content-top">

            <?php
            $today = date("Y-m-d");
            $qry2 = mysqli_query($con, "select * from tbl_movie");

            while ($m = mysqli_fetch_array($qry2)) {
            ?>

                <div class="movie-item">
                    <div class="imageRow">
                        <div class="single">
                            <a href="about.php?id=<?php echo $m['movie_id']; ?>"><img src="<?php echo $m['image']; ?>" alt="" class="movie-image" /></a>
                        </div>
                        <div class="movie-text">
                            <h4 class="h-text"><a href="about.php?id=<?php echo $m['movie_id']; ?>" style="text-decoration:none;"><?php echo $m['movie_name']; ?></a></h4>
                            Cast: <span class="color2"><?php echo $m['cast']; ?></span><br>
                        </div>
                    </div>
                </div>

            <?php
            }
            ?>

        </div>
        <div class="clear"></div>
    </div>
</div>
<?php include('footer.php'); ?>
