<div class="footer">
  <div class="footer-wrap">
    <div class="footer-top">
      <div class="footer-section">
        <div class="footer-nav">
          <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="movies_events.php">Movies</a></li>
            <li><a href="login.php">Login</a></li>
          </ul>
        </div>
      </div>

      <div class="footer-section">
        <div class="textcontact">
          <p>Theatre Assistance<br>
          <b>VisionTix</b> Movie Theatre Booking System<br>
          Ph: 9845312876</p>
        </div>
      </div>

      <div class="footer-section">
        <div class="call_info">
          <p class="txt_3">Call us toll free:</p>
          <p class="txt_4">1 296 354 54762</p>
        </div>
      </div>
    </div>

    <hr>

    <div class="footer-bottom">
      <!-- Social Media Icons (Now above copyright) -->
      <div class="footer-social-row" style="margin-bottom: 15px;">
        <a href="https://www.facebook.com" target="_blank"><img src="admin/news_images/fb.png" alt="Facebook" /></a>
        <a href="https://www.twitter.com" target="_blank"><img src="admin/news_images/x.png" alt="Twitter" /></a>
        <a href="https://www.instagram.com" target="_blank"><img src="admin/news_images/instagram.png" alt="Instagram" /></a>
        <a href="https://www.youtube.com" target="_blank"><img src="admin/news_images/youtube.png" alt="YouTube" /></a>
        <a href="https://www.pinterest.com" target="_blank"><img src="admin/news_images/pintrest.png" alt="Pinterest" /></a>
        <a href="https://www.linkedin.com" target="_blank"><img src="admin/news_images/tele.png" alt="LinkedIn" /></a>
      </div>

      <p class="copyright">
        Copyright 2025 © Bigtree Entertainment Pvt. Ltd. All Rights Reserved. <br>
        The content and images used on this site are copyright protected and belong to the respective owners.
        Unauthorized use is prohibited and punishable by law.
      </p>
    </div>
  </div>
</div>

<style>
.footer {
  background-color: #1c1c1c;
  color: #999;
  font-size: 13px;
  padding: 40px 0 20px;
  text-align: center;
}

.footer-wrap {
  max-width: 1200px;
  margin: auto;
}

.footer-top {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
  margin-bottom: 20px;
}

.footer-section {
  flex: 1;
  min-width: 200px;
  margin: 10px;
}

.footer-nav ul {
  list-style: none;
  padding: 0;
}

.footer-nav ul li {
  margin: 8px 0;
}

.footer-nav a {
  text-decoration: none;
  color: #ccc;
  transition: color 0.3s ease;
}

.footer-nav a:hover {
  color: #fff;
}

.textcontact, .call_info {
  line-height: 1.6;
}

.footer-bottom {
  margin-top: 20px;
}

.footer-social-row {
  margin-bottom: 15px;
}

.footer-social-row a img {
  width: 24px;
  margin: 0 8px;
  opacity: 0.7;
  transition: 0.3s ease;
}

.footer-social-row a img:hover {
  opacity: 1;
  transform: scale(1.2);
}

hr {
  border: none;
  height: 1px;
  background: #444;
  margin: 20px 0;
}

.txt_3 {
  font-weight: bold;
  color: #ccc;
  margin-bottom: 5px;
}

.txt_4 {
  font-size: 16px;
  color: #fff;
}

@media (max-width: 768px) {
  .footer-top {
    flex-direction: column;
    align-items: center;
  }

  .footer-section {
    text-align: center;
  }
}
</style>
